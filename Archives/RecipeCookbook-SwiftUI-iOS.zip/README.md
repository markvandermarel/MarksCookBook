# RecipeCookbook

RecipeCookbook is a native SwiftUI cookbook app for iPhone and iPad. It digitizes recipes from cookbook photos or recipe websites, extracts structured recipe content, stores recipes offline with SwiftData, and saves recipe images through a OneDrive-ready storage layer.

## Requirements

- Xcode 15 or newer
- iOS/iPadOS 17 or newer
- A physical iPhone or iPad for camera capture
- A Microsoft Entra app registration for production OneDrive uploads

## Run the App

1. Open `RecipeCookbook.xcodeproj` in Xcode.
2. Select the `RecipeCookbook` scheme.
3. Choose an iPhone or iPad simulator for URL import and browsing, or a physical device for camera OCR.
4. Build and run.

The app uses `MockOneDriveService` by default, so it compiles and runs without Microsoft credentials. Mock uploads are written into the app's Application Support container and are represented as `/Apps/RecipeCookbook/...` paths.

## Features

- iPhone recipe library with compact cards/list rows.
- iPad `NavigationSplitView` with recipe list and detail pane.
- Search by recipe title or ingredient.
- Multi-ingredient filters with `Match All` and `Match Any` modes.
- Add recipe from camera photo without saving to the Photos library.
- Apple Vision OCR for scanned recipe pages.
- Add recipe from URL with schema.org Recipe JSON-LD extraction and HTML fallback.
- Structured SwiftData models for recipes, ingredients, instruction steps, images, and source metadata.
- Step-by-step cooking mode with large readable instructions, swiping, next/previous controls, and list mode.
- Serving size scaling with original quantities preserved.
- Unit conversion for common US, British/imperial, and metric cooking units.
- Multiple recipe images: scanned page, website image, and user-added dish photo.
- Offline-first local storage with pending-upload image state.

## Microsoft Graph / OneDrive Setup

The production integration point is `GraphOneDriveService`.

1. Create an app registration in the Microsoft Entra admin center.
2. Add an iOS redirect URI for MSAL, for example:
   `msauth.<bundle-id>://auth`
3. Add Microsoft Graph delegated permissions:
   - `Files.ReadWrite.AppFolder`
   - `offline_access`
   - `User.Read`
4. Add the MSAL Swift package to the Xcode project:
   `https://github.com/AzureAD/microsoft-authentication-library-for-objc`
5. Implement a production `MicrosoftAccountServicing` adapter that returns an access token from MSAL.
6. Replace the mock service in `AppServices.makeDefault()` with:
   `GraphOneDriveService(accessTokenProvider: yourTokenProvider)`

Uploads use Microsoft Graph's app-root path:

```text
/Apps/RecipeCookbook/
```

## Privacy Notes

- Camera captures are handled in-app through `UIImagePickerController`.
- The code never calls `UIImageWriteToSavedPhotosAlbum`.
- Recipe scans and dish photos are stored in the app container first, then uploaded through the OneDrive service.
- If upload fails, the image stays local and is marked `pendingUpload`.

## Architecture

```text
RecipeCookbook/
  Models/          SwiftData models and parsed DTOs
  Views/           SwiftUI screens and reusable UI
  ViewModels/      Screen state and user actions
  Services/        OCR, parsing, URL import, OneDrive, scaling, conversion, search
  Repositories/    SwiftData repository boundary
  Utilities/       Formatting and cleanup helpers
```

Key interfaces:

- `RecipeRepository`
- `OCRRecognizing`
- `RecipeParsing`
- `URLRecipeImporting`
- `OneDriveServicing`
- `MicrosoftAccountServicing`

The parser is deterministic today. `RecipeParsing` is the replacement point for a future LLM/API parser.

## Tests

The `RecipeCookbookTests` target covers:

- Ingredient parsing
- Instruction step splitting
- Serving size scaling
- Unit conversion
- URL recipe extraction from sample schema.org HTML
- Recipe search and ingredient filter logic

Run tests from Xcode with `Product > Test`.

## Known Limitations

- Microsoft sign-in is mocked until MSAL is added and wired to `GraphOneDriveService`.
- Background retry sync is modeled with `pendingUpload`, but a full retry scheduler is not yet implemented.
- HTML fallback parsing is intentionally conservative. JSON-LD recipe pages will produce the best results.
- Ingredient density conversions, such as cups of flour to grams, are preserved or marked approximate unless a future density table is added.
- OCR quality depends on lighting, page layout, and camera focus.

## Future Improvements

- Add MSAL-backed account settings and token refresh.
- Add a pending upload sync queue using `BGTaskScheduler`.
- Add an AI parser behind `RecipeParsing` for better OCR cleanup and ingredient structuring.
- Add cuisine, tags, prep time, cook time, and favorites filters.
- Add editable recipe forms for correcting OCR and URL imports.
- Add JSON backup export/import through OneDrive.
